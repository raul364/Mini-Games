package com.daizy.core.music;

public abstract class MusicAPI {

    public static void init() {
    }
}
