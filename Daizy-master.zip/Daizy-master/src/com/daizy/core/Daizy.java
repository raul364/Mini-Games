package com.daizy.core;

import com.daizy.core.gui.GUI;

import javax.swing.*;

public class Daizy {

    public static void main(String args[]) {
        new GUI("Poop");
    }
}
