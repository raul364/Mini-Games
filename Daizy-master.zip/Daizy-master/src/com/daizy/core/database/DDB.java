package com.daizy.core.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DDB {

    private static Connection connection;

    public DDB() {
    }
}
