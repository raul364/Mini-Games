package com.daizy.core.tts;

public class VoiceRecognition {
}
